#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>

using namespace std;
class vec3
{
private: 
	int x;
	int y;
	int z;
public:
	
	vec3()
	{
		x = 0;
		y = 0;
		z = 0;
	}
	vec3(int xp, int yp, int zp)
	{
		x = xp;
		y = yp;
		z = zp;
	}
	void Normalize()
	{
		float denom;

		denom = sqrt(x ^ 2 + y ^ 2 + z ^ 2);
		cout << x/denom;
		cout << " " << y/denom;
		cout << " " << z/denom;
	}
	void Zero()
	{
		x = 0;
		y = 0;
		z = 0;
	}
	void IsZero()
	{
		bool isZero;
		isZero = false;
		if (x == 0 && y == 0 && z == 0)
		{
			isZero = true;
		}
		else
		{
			isZero = false;
		}
		cout << isZero;
	}
	void DistanceTo(vec3* SecondVec)
	{
		float res1;
		float res2;
		float res3;
		float resf;

		res1 = (SecondVec->x - x) * (SecondVec->x - x);
		res2 = (SecondVec->y - y) * (SecondVec->y - y);
		res3 = (SecondVec->z - z) * (SecondVec->z - z);

		resf = res1 + res2 + res3;
		cout << "Distance: " << sqrt(resf);
	}
	
	vec3 operator+(const vec3& citm) const
	{
		vec3 resul;
		resul.x = this->x + citm.x;
		resul.y = this->y + citm.y;
		resul.z = this->z + citm.z;

		cout << " " << resul.x;
		cout << " " << resul.y;
		cout << " " << resul.z;

		return resul;
	}
	
	vec3 operator-(const vec3& citm) const
	{
		vec3 resul;
		resul.x = this->x - citm.x;
		resul.y = this->y - citm.y;
		resul.z = this->z - citm.z;

		cout << " " << resul.x;
		cout << " " << resul.y;
		cout << " " << resul.z;

		return resul;
	}
	
	bool operator+=(const vec3 &citm) const
	{
		return this->x >= citm.x && this->y >= citm.y && this->z >= citm.z;
	}

	bool operator-=(const vec3& citm) const
	{
		return this->x <= citm.x && this->y <= citm.y && this->z <= citm.z;
	}

	vec3 &operator=(const vec3 &citm)
	{
		this->x = citm.x;
		this->y = citm.y;
		this->z = citm.z;
	}

	bool operator==(const vec3& citm) const
	{
		return  this->x == citm.x && this->y == citm.y && this->z == citm.z;
	}

	~vec3()
	{

	}
	
};



int main()
{
	vec3 citm(1, 2, 3);
	vec3 citm2(6, 7, 8);

	citm.Normalize();
	printf("\n");
	//citm.Zero();
	citm.IsZero();
	printf("\n");
	citm.DistanceTo(&citm2);
	return 0;
	system("pause");
}